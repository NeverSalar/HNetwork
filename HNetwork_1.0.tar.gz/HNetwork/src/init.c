#include <R.h>
#include <Rinternals.h>
#include <stdlib.h> // for NULL
#include <R_ext/Rdynload.h>

/* FIXME: 
   Check these declarations against the C/Fortran source code.
*/

/* .Call calls */
extern SEXP _HNetwork_GD_cpp(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP _HNetwork_GD_cpp_EU(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP _HNetwork_GD_cpp_PT(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP _HNetwork_grad_K(SEXP, SEXP, SEXP);
extern SEXP _HNetwork_grad_Z(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP _HNetwork_K_alone_cpp(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP _HNetwork_retraction(SEXP, SEXP, SEXP);
extern SEXP _HNetwork_retraction_Z(SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP _HNetwork_total_loss_cpp(SEXP, SEXP, SEXP);

static const R_CallMethodDef CallEntries[] = {
    {"_HNetwork_GD_cpp",         (DL_FUNC) &_HNetwork_GD_cpp,         13},
    {"_HNetwork_GD_cpp_EU",      (DL_FUNC) &_HNetwork_GD_cpp_EU,       9},
    {"_HNetwork_GD_cpp_PT",      (DL_FUNC) &_HNetwork_GD_cpp_PT,      13},
    {"_HNetwork_grad_K",         (DL_FUNC) &_HNetwork_grad_K,          3},
    {"_HNetwork_grad_Z",         (DL_FUNC) &_HNetwork_grad_Z,          6},
    {"_HNetwork_K_alone_cpp",    (DL_FUNC) &_HNetwork_K_alone_cpp,    12},
    {"_HNetwork_retraction",     (DL_FUNC) &_HNetwork_retraction,      3},
    {"_HNetwork_retraction_Z",   (DL_FUNC) &_HNetwork_retraction_Z,    5},
    {"_HNetwork_total_loss_cpp", (DL_FUNC) &_HNetwork_total_loss_cpp,  3},
    {NULL, NULL, 0}
};

void R_init_HNetwork(DllInfo *dll)
{
    R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
    R_useDynamicSymbols(dll, FALSE);
}
