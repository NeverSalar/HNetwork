// [[Rcpp::depends(RcppArmadillo, RcppDist)]]

#include <RcppDist.h>
// #include <math.h>
#include <list>
#include <vector>
#include <iostream>

using namespace Rcpp;
using namespace arma;
using namespace std;

using std::log;
using std::pow;
using std::acosh;
using std::tanh;
using std::exp;
using std::abs;


// [[Rcpp::export]]
double total_loss_cpp(arma::mat& A, arma::mat& P, int n){
	arma::mat temp = log(P);
	temp.diag() = zeros(n, 1.0);
	return(- accu(A % temp + (1.0 - A) % log(1.0 - P)));
}

// [[Rcpp::export]]
double grad_K(double K, arma::mat& Diff, arma::mat& Arc){
	return(accu(Diff % Arc) / 2.0 / pow(K, 1.5));
}

// [[Rcpp::export]]
arma::mat grad_Z(double K, arma::mat& Diff, arma::mat& M_prod, arma::mat& Z, int n, arma::mat L){
	// Be cautious of the initial diagonal value of M_prod!
	arma::mat denomi = 1.0 / sqrt(pow(M_prod, 2) - 1.0);
	denomi.diag() = zeros(n, 1);
	arma::mat h_grad = 2 / sqrt(K) * (Diff % denomi) * Z;
	return(h_grad);
}

// [[Rcpp::export]]
arma::mat retraction(arma::mat v, arma::mat x, arma::mat L){
	double vn = sqrt(max(accu(v * L * v.t()), 1e-6));
	return(cosh(vn) * x + sinh(vn) / vn * v);
}

// [[Rcpp::export]]
arma::mat retraction_Z(arma::mat grad_Z, arma::mat Z, int n, arma::mat L, int k){
	arma::mat Z_new = zeros(n, size(Z)[1]);
	arma::mat grad_i = zeros(1, size(Z)[1]);
	arma::mat I_zero = eye(k, k);
	I_zero.diag()[k - 1] = 0.0;
	for (int i = 0; i < n; i++){
		grad_i = grad_Z.row(i) + (Z.row(i) * L * (grad_Z.row(i)).t()) * Z.row(i);
		Z_new.row(i) = retraction(grad_i, Z.row(i), L);
		// CODE: enforce Z to live on the manifold
		Z_new(i, k - 1) = sqrt(1 + accu(Z_new.row(i) * I_zero * Z_new.row(i).t()));
		// sqrt(1 + pow(Z_new(i, 0), 2) + pow(Z_new(i, 1), 2));
	}
	return(Z_new);
}


// [[Rcpp::export]]
List GD_cpp(arma::mat& A, arma::mat& M, int k, arma::mat& Z_true, arma::mat& P_true, arma::mat& Theta_true, double K_true, double init_K, arma::mat& init_Z, double eta_K = 1.0, double eta_Z = 1.0, double eps = 1e-6, int max_iter = 1000){
	// Note that initialization is not being put here

	double update_dev = 1.0;
	int iter = 0;
	double K = init_K;
	arma::mat Z = init_Z;

	int n = size(A)[0];
	arma::mat L = eye(k, k);
	L.diag()[k - 1] = -1.0;
	arma::vec vec_1 = ones(n, 1);

	// some initializations for checking consistency of simulation
	arma::mat M_prod_true = Z_true * L * Z_true.t();
	M_prod_true.diag() = - ones(n, 1);
	double M_prod_true_norm = pow(norm(M_prod_true, "fro"), 2);
	double P_true_norm = pow(norm(P_true, "fro"), 2);
	double Theta_true_norm = pow(norm(Theta_true, "fro"), 2);
	// double M_prod_two_norm = norm(M_prod_true, 2);

	arma::vec Loss = zeros(max_iter, 1);
	arma::vec ERR_MZ = zeros(max_iter, 1);
	arma::vec ESTI_K = zeros(max_iter, 1);
	arma::vec ERR_K = zeros(max_iter, 1);
	arma::vec ERR_P = zeros(max_iter, 1);
	arma::vec ERR_Theta = zeros(max_iter, 1);
	// vec VEC_QUA_GRAD_K = zeros(max_iter, 1);
	// vec VEC_QUA_GRAD_Z = zeros(max_iter, 1);

	arma::mat P = zeros(n, n);
	arma::mat Theta = zeros(n, n);
	arma::mat M_prod = zeros(n, n);


	// start looping
	while(update_dev > eps && iter < max_iter){
		// preparing for calculation of gradients
		M_prod = Z * L * Z.t();
		// NEW CODE: increase stability of optimization by thresholding the upper / lower bound of M_prod
		M_prod = clamp(M_prod, -1e10, - 1 - 1e-6);
		M_prod.diag() = - ones(n, 1);
		arma::mat Arc = acosh(- M_prod);
		Theta = - Arc / sqrt(K);
		// NEW CODE: increase stability of optimization by thresholding the upper / lower bound of Theta
		Theta = clamp(Theta, -10.0, -1e-4);
		Theta.diag() = zeros(n, 1);

		// for link function logit(x/2)
		P = tanh(Theta / 2) + 1;


		// for link function logit(x)
		// arma::mat P = (tanh(Theta / 2) + 1) / 2;
		// for link function exp(x)
		// arma::mat P = exp(Theta);

		// for all link functions
		P.diag() = zeros(n, 1);
		arma::mat Diff = P - A;


		// DEBUG CODE
		// if (! arma::is_finite(accu(P))){
		// 	return(List::create(Named("Theta") = Theta, Named("P") = P, Named("M_prod") = M_prod, Named("Z") = Z));
		// }

		// for link function logit(x/2)
		Diff = (1.0 / (1.0 - exp(Theta))) % Diff;
		// for link function exp(x)
		// Diff = (1.0 / (1.0 - P)) % Diff;

		// for all link functions
		Diff.diag() = zeros(n, 1);

		// 09/29/2021 with M representing non-missing entries
		Diff = Diff % M;

		// recording errors
		Loss[iter] = total_loss_cpp(A, P, n);
		// ERR_MZ[iter] = pow(norm(M_prod_true - M_prod, "fro"), 2) / n / n;
		ERR_MZ[iter] = pow(norm(M_prod_true - M_prod, "fro"), 2) / M_prod_true_norm;
		ESTI_K[iter] = K;
		ERR_K[iter] = abs(K - K_true);
		// ERR_P[iter] = pow(norm(P_true - P, "fro"), 2) / n / n;
		ERR_P[iter] = pow(norm(P_true - P, "fro"), 2) / P_true_norm;
		// ERR_Theta[iter] = pow(norm(Theta_true - Theta, "fro"), 2) / n / n;
		ERR_Theta[iter] = pow(norm(Theta_true - Theta, "fro"), 2) / Theta_true_norm;

		// updating parameters with with gradient descent
		double gradient_K = grad_K(K, Diff, Arc);
		arma::mat gradient_Z = grad_Z(K, Diff, M_prod, Z, n, L);
		// NEW CODE: STABLIZE GRADIENT OF Z WITH A NORMALIZATION
		// gradient_Z = gradient_Z / (abs(gradient_Z)).max();


		K = std::max(K - eta_K * gradient_K, 0.001);
		// DEBUG CODE
		// if(! arma::is_finite(accu(retraction_Z(- eta_Z * gradient_Z, Z, n, L)))){
		// 	return(List::create(Named("Theta") = Theta, Named("P") = P, Named("M_prod") = M_prod, Named("grad_Z") = gradient_Z, Named("Z") = Z));
		// }
		Z = retraction_Z(- eta_Z * gradient_Z, Z, n, L, k);

		// update conditions
		if (iter != 0){
			update_dev = abs(Loss[iter] - Loss[iter - 1]) / n / n;
		}
		iter++;
	}

	List res = List::create(Named("K") = K, Named("Z") = Z, Named("Loss") = Loss, Named("ERR_MZ") = ERR_MZ, Named("ERR_P") = ERR_P, Named("ERR_Theta") = ERR_Theta, Named("ESTI_K") = ESTI_K, Named("ERR_K") = ERR_K, Named("iter") = iter);
	return(res);
}


// [[Rcpp::export]]
List GD_cpp_EU(arma::mat& A, arma::mat& M, int k, arma::mat& P_true, arma::mat& Theta_true, arma::mat& init_Z, double eta_Z = 1.0, double eps = 1e-6, int max_iter = 1000){
	// Fit Euclidean model, return errs on P and Theta
	// Note that initialization is not being put here

	double update_dev = 1.0;
	int iter = 0;
	arma::mat Z = init_Z;

	int n = size(A)[0];

	// some initializations for checking consistency of simulation
	double P_true_norm = pow(norm(P_true, "fro"), 2);
	double Theta_true_norm = pow(norm(Theta_true, "fro"), 2);

	arma::vec Loss = zeros(max_iter, 1);
	arma::vec ERR_P = zeros(max_iter, 1);
	arma::vec ERR_Theta = zeros(max_iter, 1);

	arma::mat P = zeros(n, n);
	arma::mat Theta = zeros(n, n);

	while(update_dev > eps && iter < max_iter){
		// preparing for calculation of gradients
		arma::mat Gram_Z = Z * Z.t();
		Theta = ones(n, 1) * (Gram_Z.diag()).t() + Gram_Z.diag() * (ones(n, 1)).t() - 2 * Gram_Z;
		// NEW CODE: increase stability of optimization by thresholding the upper / lower bound of Theta
		Theta = clamp(Theta, 1e-8, 100.0);
		Theta = - sqrt(Theta);
		Theta.diag() = zeros(n, 1);

		// for link function logit(x/2)
		P = tanh(Theta / 2) + 1;

		// for link function logit(x)
		// arma::mat P = (tanh(Theta / 2) + 1) / 2;
		// for link function exp(x)
		// arma::mat P = exp(Theta);

		// for all link functions
		P.diag() = zeros(n, 1);
		
		arma::mat Diff = P - A;

		// for link function logit(x/2)
		Diff = (1.0 / (1.0 - exp(Theta))) % Diff;
		// for link function exp(x)
		// Diff = (1.0 / (1.0 - P)) % Diff;

		// for all link functions
		Diff.diag() = zeros(n, 1);

		// recording errors
		Loss[iter] = total_loss_cpp(A, P, n);
		// ERR_MZ[iter] = pow(norm(M_prod_true - M_prod, "fro"), 2) / n / n;
		// ERR_P[iter] = pow(norm(P_true - P, "fro"), 2) / n / n;
		ERR_P[iter] = pow(norm(P_true - P, "fro"), 2) / P_true_norm;
		// ERR_Theta[iter] = pow(norm(Theta_true - Theta, "fro"), 2) / n / n;
		ERR_Theta[iter] = pow(norm(Theta_true - Theta, "fro"), 2) / Theta_true_norm;

		// updating parameters with with coordinate descent
		// arma::mat D_T = Diff % (1 / Theta);
		// 09/29/2021 with M representing non-missing entries
		arma::mat D_T = Diff % M % (1 / Theta);
		
		// D_T = D_T / D_T.max();
		D_T.diag() = zeros(n, 1);
		
		arma::mat gradient_Z = Z % (D_T * ones(n, k)) - D_T * Z;
		Z = Z - eta_Z * gradient_Z;

		// update conditions
		if (iter != 0){
			update_dev = abs(Loss[iter] - Loss[iter - 1]) / n / n;
		}
		iter++;
	}

	List res = List::create(Named("K") = 0, Named("Z") = Z, Named("Loss") = Loss, Named("P") = P, Named("Theta") = Theta, Named("ERR_P") = ERR_P, Named("ERR_Theta") = ERR_Theta, Named("iter") = iter);
	return(res);

}



// [[Rcpp::export]]
List GD_cpp_PT(arma::mat& A, arma::mat& M, int k, arma::mat& Z_true, arma::mat& P_true, arma::mat& Theta_true, double K_true, double init_K, arma::mat& init_Z, double eta_K = 1.0, double eta_Z = 1.0, double eps = 1e-6, int max_iter = 1000){
	// Fit hyerpbolic model while only return errs on P and Theta
	// Note that initialization is not being put here


	double update_dev = 1.0;
	int iter = 0;
	double K = init_K;
	arma::mat Z = init_Z;

	int n = size(A)[0];
	arma::mat L = eye(k, k);
	L.diag()[k - 1] = -1.0;
	arma::vec vec_1 = ones(n, 1);

	// some initializations for checking consistency of simulation
	double P_true_norm = pow(norm(P_true, "fro"), 2);
	double Theta_true_norm = pow(norm(Theta_true, "fro"), 2);
	// double M_prod_two_norm = norm(M_prod_true, 2);

	arma::vec Loss = zeros(max_iter, 1);
	arma::vec ESTI_K = zeros(max_iter, 1);
	arma::vec ERR_K = zeros(max_iter, 1);
	arma::vec ERR_P = zeros(max_iter, 1);
	arma::vec ERR_Theta = zeros(max_iter, 1);
	// vec VEC_QUA_GRAD_K = zeros(max_iter, 1);
	// vec VEC_QUA_GRAD_Z = zeros(max_iter, 1);

	// start looping
	while(update_dev > eps && iter < max_iter){
		// preparing for calculation of gradients
		arma::mat M_prod = Z * L * Z.t();
		M_prod.diag() = - ones(n, 1);
		arma::mat Arc = acosh(- M_prod);
		arma::mat Theta = - Arc / sqrt(K);

		// for link function logit(x/2)
		arma::mat P = tanh(Theta / 2) + 1;
		// for link function logit(x)
		// arma::mat P = (tanh(Theta / 2) + 1) / 2;
		// for link function exp(x)
		// arma::mat P = exp(Theta);

		// for all link functions
		P.diag() = zeros(n, 1);
		arma::mat Diff = P - A;

		// for link function logit(x/2)
		Diff = (1.0 / (1.0 - exp(Theta))) % Diff;
		// for link function exp(x)
		// Diff = (1.0 / (1.0 - P)) % Diff;

		// for all link functions
		Diff.diag() = zeros(n, 1);

		// 09/29/2021 with M representing non-missing entries
		Diff = Diff % M;

		// recording errors
		Loss[iter] = total_loss_cpp(A, P, n);
		// ERR_MZ[iter] = pow(norm(M_prod_true - M_prod, "fro"), 2) / n / n;
		ESTI_K[iter] = K;
		ERR_K[iter] = abs(K - K_true);
		// ERR_P[iter] = pow(norm(P_true - P, "fro"), 2) / n / n;
		ERR_P[iter] = pow(norm(P_true - P, "fro"), 2) / P_true_norm;
		// ERR_Theta[iter] = pow(norm(Theta_true - Theta, "fro"), 2) / n / n;
		ERR_Theta[iter] = pow(norm(Theta_true - Theta, "fro"), 2) / Theta_true_norm;

		// updating parameters with with gradient descent
		double gradient_K = grad_K(K, Diff, Arc);
		arma::mat gradient_Z = grad_Z(K, Diff, M_prod, Z, n, L);

		K = std::max(K - eta_K * gradient_K, 0.001);
		Z = retraction_Z(- eta_Z * gradient_Z, Z, n, L, k);

		// update conditions
		if (iter != 0){
			update_dev = abs(Loss[iter] - Loss[iter - 1]) / n / n;
		}
		iter++;
	}

	List res = List::create(Named("K") = K, Named("Z") = Z, Named("Loss") = Loss, Named("ERR_P") = ERR_P, Named("ERR_Theta") = ERR_Theta, Named("ESTI_K") = ESTI_K, Named("ERR_K") = ERR_K, Named("iter") = iter);
	return(res);
}




// [[Rcpp::export]]
List K_alone_cpp(arma::mat& A, int k, arma::mat& Z_true, arma::mat& P_true, arma::mat& Theta_true, double K_true, double init_K, arma::mat& Z, double eta_K = 1.0, double eta_Z = 1.0, double eps = 1e-6, int max_iter = 1000){

	double update_dev = 1.0;
	int iter = 0;
	double K = init_K;

	int n = size(A)[0];
	arma::mat L = eye(k, k);
	L.diag()[k - 1] = -1.0;

	// these holds the same when updating K only
	arma::mat M_prod = Z * L * Z.t();
	M_prod.diag() = - ones(n, 1);
	arma::mat Arc = acosh(- M_prod);

	// some initializations for checking consistency of simulation
	double P_true_norm = pow(norm(P_true, "fro"), 2);
	double Theta_true_norm = pow(norm(Theta_true, "fro"), 2);
	// double M_prod_two_norm = norm(M_prod_true, 2);

	vec Loss = zeros(max_iter, 1);
	vec ESTI_K = zeros(max_iter, 1);
	vec ERR_K = zeros(max_iter, 1);
	vec ERR_P = zeros(max_iter, 1);
	vec ERR_Theta = zeros(max_iter, 1);
	// vec VEC_QUA_GRAD_K = zeros(max_iter, 1);
	// vec VEC_QUA_GRAD_Z = zeros(max_iter, 1);

	// start looping
	while(update_dev > eps && iter < max_iter){
		// preparing for calculation of gradients
		
		arma::mat Theta = - Arc / sqrt(K);

		// for link function logit(x/2)
		arma::mat P = tanh(Theta / 2) + 1;
		// for link function logit(x)
		// mat P = (tanh(Theta / 2) + 1) / 2;
		// for link function exp(x)
		// mat P = exp(Theta);

		// for all link functions
		P.diag() = zeros(n, 1);
		arma::mat Diff = P - A;

		// for link function logit(x/2)
		Diff = (1.0 / (1.0 - exp(Theta))) % Diff;
		// for link function exp(x)
		// Diff = (1.0 / (1.0 - P)) % Diff;

		// for all link functions
		Diff.diag() = zeros(n, 1);

		// recording errors for simulation
		Loss[iter] = total_loss_cpp(A, P, n);
		// ERR_MZ[iter] = pow(norm(M_prod_true - M_prod, "fro"), 2) / n / n;
		ESTI_K[iter] = K;
		ERR_K[iter] = abs(K - K_true);
		// ERR_P[iter] = pow(norm(P_true - P, "fro"), 2) / n / n;
		ERR_P[iter] = pow(norm(P_true - P, "fro"), 2) / P_true_norm;
		// ERR_Theta[iter] = pow(norm(Theta_true - Theta, "fro"), 2) / n / n;
		ERR_Theta[iter] = pow(norm(Theta_true - Theta, "fro"), 2) / Theta_true_norm;

		//----------- update with coordinate descent -----------
		double gradient_K = grad_K(K, Diff, Arc);
		K = K - eta_K * gradient_K;

		// update conditions
		// update_dev = abs(gradient_K);
		if (iter != 0){
			update_dev = abs(Loss[iter] - Loss[iter - 1]) / n / n;
		}
		// update_dev = max(abs(gradient_K), (abs(gradient_Z)).max());
		// update_dev = (abs(gradient_Z)).max();
		iter++;
	}
	// List res = List::create(Named("K") = K, Named("Z") = Z, Named("Loss") = Loss, Named("ERR_MZ") = ERR_MZ, Named("ERR_P") = ERR_P, Named("ERR_Theta") = ERR_Theta, Named("ESTI_K") = ESTI_K, Named("VEC_QUA_GRAD_K") = VEC_QUA_GRAD_K, Named("VEC_QUA_GRAD_Z") = VEC_QUA_GRAD_Z, Named("iter") = iter);
		List res = List::create(Named("K") = K, Named("Loss") = Loss, Named("ERR_P") = ERR_P, Named("ERR_Theta") = ERR_Theta, Named("ESTI_K") = ESTI_K, Named("ERR_K") = ERR_K, Named("iter") = iter);
	return(res);
}









